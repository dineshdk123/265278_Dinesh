from django import forms
from django.contrib.auth.models import User
from django.contrib.auth.forms import UserCreationForm

class RegisterForm(UserCreationForm):
    username = forms.CharField(
        max_length=150,
        help_text="Give a proper user name "
    )
    password1 = forms.CharField(
        widget=forms.PasswordInput,
        help_text="Don't forget your password"
    )

    password2 = forms.CharField(
        widget=forms.PasswordInput,
        help_text="Repeat your password."
    )

    class Meta:
        model = User
        fields = ['username', 'email', 'password1', 'password2']

class DepositForm(forms.Form):
    amount = forms.DecimalField(min_value=1)

class WithdrawForm(forms.Form):
    amount = forms.DecimalField(min_value=1)
