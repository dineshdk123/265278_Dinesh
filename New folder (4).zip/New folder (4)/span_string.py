li = []
def spansub(stri, substri):
    x = len(substri)
    for i in range(len(stri)):
        subs = x+i
        if substri == stri[i:subs]:
            li.append((i,subs))
 
    print(len(li), li)
 
if __name__ == "__main__":
    strio = input("enter the string:")
    substrio = input("enter the sub_string:")
    spansub(strio, substrio) 


# import span
 
# strio = input("enter the string")
# substrio = input("enter the sub_string")
# span.spansub(strio, substrio)

# s= "mississippi"
# ss = "ss"
# start = s.find(ss)
# end = start + len(ss)
# print(start, end)
# start1 = s.find(ss, end)
# end1 = start1 + len(ss)
# print(start1, end1)

