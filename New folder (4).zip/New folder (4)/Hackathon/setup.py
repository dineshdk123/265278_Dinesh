from setuptools import setup

setup(
    name='ProblemSolve',
    version='0.1',
    packages=['ProblemSolve'],
    description='A simple Python package',
    author='Dinesh Kumar P',
    author_email='your.email@example.com',
    url="",
)