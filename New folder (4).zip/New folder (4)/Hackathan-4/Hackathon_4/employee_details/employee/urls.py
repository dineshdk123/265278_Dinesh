from django.urls import path
from . import views

urlpatterns=[
    path('emp',views.employee_det,name='emp'),
    path('net_salary',views.nnet_salary, name='net_salary'),
    path('jumble', views.jumble_word, name='jumble_word')
]