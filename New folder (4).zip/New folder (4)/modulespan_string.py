import span_string
 
strio = input("enter the string:")
substrio = input("enter the sub_string:")
span_string.spansub(strio, substrio)