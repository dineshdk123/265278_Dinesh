from pandas.tseries.offsets import MonthBegin
from pandas.tseries.offsets import WeekOfMonth 
from datetime import datetime
 
offset1 =MonthBegin(n=4)
 
offset2 = WeekOfMonth (week=3, weekday=1)
 
dt =datetime (2022, 8, 22)
new_dt = dt + offset1 + offset2
 
print(new_dt)