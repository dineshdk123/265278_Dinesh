#guess random number 
import random
a= random.randint(1,50)
guess = 0
while True:
    n=int(input("enter the number : "))
 
    if n==a:
        print("Yuu guess the right number")
        break
    else:
        print(f"you have only {4-guess} chances")
        guess+=1
    if guess == 5:
        print("loss the game ")
        print(f"the number is {a}")
        break