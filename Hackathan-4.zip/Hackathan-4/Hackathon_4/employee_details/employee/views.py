from django.shortcuts import render
import random
# Create your views here.
def employee_det(request):
    return render(request, 'employee/employee_det.html')

def nnet_salary(request):
    if request.method == 'POST':
        name = request.POST['name']
        age = request.POST['age']
        company = request.POST['company']
        gross_salary = float(request.POST['gross_salary'])
        tax = float(request.POST['tax'])
        bonus = float(request.POST['bonus'])
 
        net_salary = gross_salary - (gross_salary * tax / 100) + (gross_salary * bonus / 100)
 
        context = {
            'name': name,
            'net_salary': round(net_salary, 2)
        }
        return render(request, 'employee/result.html', context)
    return render(request, 'employee/salaryform.html')  

# function for JUMBLE WORD 
def jumble_word(request):
    jumbled = ''
    if request.method == 'POST':
        word = request.POST.get('word')
        jumbled = ''.join(random.sample(word, len(word)))

    return render(request, 'employee/jumble_word.html', {'jumbled': jumbled})
