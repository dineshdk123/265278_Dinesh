import uuid
 
class Student:
    def __init__(self, name, age, grade, student_id=None):
        self.id = student_id if student_id else str(uuid.uuid4())
        self.name = name
        self.age = age
        self.grade = grade
 
    # Convert a Student object to dictionary format
    def to_dict(self):
        return {
            "id": self.id,
            "name": self.name,
            "age": self.age,
            "grade": self.grade
        }
 
    # Create a Student object from dictionary
    @staticmethod
    def from_dict(data):
        return Student(
           
            name=data['name'],
            age = data["age"],
            grade=data["grade"],
            student_id=data["id"]
           
        )