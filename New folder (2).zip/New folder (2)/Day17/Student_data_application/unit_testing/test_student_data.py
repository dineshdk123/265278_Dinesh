import unittest
from student_data import Student_data
from student import Student

class TestStudentData(unittest.TestCase):

    def setUp(self):
        """Initialize a Student_data object for each test."""
        self.manager = Student_data()
        
    def test_add_student(self):
        student = self.manager.add_student("Dinesh", 23, "A")
        self.assertEqual(len(self.manager.data), 1)
        self.assertEqual(student.name, "Dinesh")
        self.assertEqual(student.age, 23)
        self.assertEqual(student.grade, "A")
        
    def test_get_all_students(self):
        self.manager.add_student("Dinesh", 23, "A")
        self.manager.add_student("Dinesh", 22, "B")
        students = self.manager.get_all_student()
        self.assertEqual(len(students), 2)
        
    def test_search_student_by_id(self):
        student = self.manager.add_student("Dinesh", 23, "A")
        found_student = self.manager.search_student(student.id)
        self.assertEqual(found_student.name, "Dinesh")
        
    def test_search_student_by_invalid_id(self):
        student = self.manager.add_student("Dinesh", 23, "A")
        found_student = self.manager.search_student("invalid-id")
        self.assertIsNone(found_student)
        
    def test_delete_student(self):
        student = self.manager.add_student("Dinesh", 23, "A")
        result = self.manager.delete_student(student.id)
        self.assertTrue(result)
        self.assertEqual(len(self.manager.data), 0)
        
    def test_delete_student_invalid_id(self):
        student = self.manager.add_student("Dinesh", 23, "A")
        result = self.manager.delete_student("invalid-id")
        self.assertFalse(result)
        
    def test_load_tasks(self):
        student_dicts = [
            {"id": "1", "name": "Dinesh", "age": 23, "grade": "A"},
            {"id": "2", "name": "Dinesh", "age": 22, "grade": "B"}
        ]
        self.manager.load_tasks(student_dicts)
        self.assertEqual(len(self.manager.data), 2)

    def test_to_dict_list(self):
        self.manager.add_student("Dinesh", 23, "A")
        student_dict_list = self.manager.to_dict_list()
        self.assertEqual(len(student_dict_list), 1)
        self.assertEqual(student_dict_list[0]["name"], "Dinesh")

if __name__ == "__main__":
    unittest.main()
