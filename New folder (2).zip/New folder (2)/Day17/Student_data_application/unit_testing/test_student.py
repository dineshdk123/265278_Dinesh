import unittest
from student import Student

class TestStudent(unittest.TestCase):
    
    def test_student_creation(self):
        student = Student(name="Dinesh", age=23, grade="A")
        self.assertEqual(student.name, "Dinesh")
        self.assertEqual(student.age, 23)
        self.assertEqual(student.grade, "A")
        self.assertIsNotNone(student.id)  # ID should be generated
        
    def test_to_dict(self):
        student = Student(name="Dinesh", age=23, grade="A")
        student_dict = student.to_dict()
        self.assertEqual(student_dict['name'], "John Doe")
        self.assertEqual(student_dict['age'], 23)
        self.assertEqual(student_dict['grade'], "A")
        self.assertIsNotNone(student_dict['id'])  # ID should be included
        
    def test_from_dict(self):
        student_dict = {
            "id": "some-uuid",
            "name": "Dinesh",
            "age": 20,
            "grade": "A"
        }
        student = Student.from_dict(student_dict)
        self.assertEqual(student.name, "Dinesh")
        self.assertEqual(student.age, 23)
        self.assertEqual(student.grade, "A")
        self.assertEqual(student.id, "some-uuid")

if __name__ == "__main__":
    unittest.main()