import unittest
from unittest.mock import patch, mock_open
from storage import Storage

class TestStorage(unittest.TestCase):
    
    @patch("builtins.open", mock_open())
    def test_save(self):
        # Mocked save function
        store = Storage(filepath='student.json')
        students = [{"id": "1", "name": "Dinesh", "age": 23, "grade": "A"}]
        store.save(students)
        
        # Verify that the save function tries to write the file
        with open("student.json", "w") as f:
            f.write('[{"id": "1", "name": "Dinesh", "age": 23, "grade": "A"}]')
        mock_open.assert_called_with('student.json', 'w')
    
    @patch("builtins.open", mock_open(read_data='[{"id": "1", "name": "Dinesh", "age": 23, "grade": "A"}]'))
    def test_load(self):
        # Mocked load function
        store = Storage(filepath='student.json')
        loaded_students = store.load()
        self.assertEqual(len(loaded_students), 1)
        self.assertEqual(loaded_students[0]["name"], "Dinesh")
        
    @patch("os.path.exists", return_value=False)  # Mock os.path.exists to return False (no file exists)
    def test_load_empty(self):
        store = Storage(filepath='student.json')
        loaded_students = store.load()
        self.assertEqual(loaded_students, [])

if __name__ == "__main__":
    unittest.main()
