# Create a text-processing tool that reads a paragraph and returns each word 
# one at a time when iterated over. You want to build a custom iterator 
# class called WordIterator that takes a string of text and lets users 
# iterate through its words using a for loop or next().
# # Sample paragraph
# paragraph = "Python is a powerful and versatile programming language."
# # Create the iterator
# word_iter = WordIterator(paragraph)
# # Iterate through the words
# for word in word_iter:
#     print(word)
# # Output
# Python
# is
# a
# powerful
# and
# versatile
# programming
# language.

class WordIterator:
    def __init__(self, text):
        self.words = text.split()
        self.index = 0
    
    def __iter__(self):
        return self
    
    def __next__(self):
        if self.index < len(self.words):
            word = self.words[self.index]
            self.index += 1
            return word
        else:
            raise StopIteration

paragraph = "Python is a powerful and versatile programming language."

word_iter = WordIterator(paragraph)
for word in word_iter:
    print(word)
