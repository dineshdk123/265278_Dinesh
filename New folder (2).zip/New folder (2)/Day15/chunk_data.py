import itertools
def chunk_data(iterable,chunk_size):
    it=iter(iterable)
    while True:
        chunk=list(itertools.islice(it,chunk_size))
        if not chunk:
            break
        yield chunk
user_id=range(1,10001)
for chunk in chunk_data(user_id,100):
    print(chunk)
    print(f"Processing chunk: {chunk[:3]}...{chunk[-3:]}")


# def chunk_data(data, chunk_size):
 
#     for i in range(0, len(data), chunk_size):
#         yield data[i:i + chunk_size]data[i:i + chunk_size]: ( This is slicing the list data to extract a portion (chunk) of size chunk_size.
#                                                               data[i:i + chunk_size] means:
#                                                               Start slicing at index i.
#                                                               Stop slicing at index i + chunk_size (exclusive).)
# user_ids = list(range(1, 10001))  # Simulating 10,000 user IDs
 
# for chunk in chunk_data(user_ids, 100):
#     print(f"Processing chunk: {chunk[:3]}...{chunk[-3:]}")
 