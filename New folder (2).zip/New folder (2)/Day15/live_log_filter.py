
# # Simulated log lines (could also be read line-by-line from a real file)
# log_lines = [
#     "2025-04-07 INFO User logged in",
#     "2025-04-07 ERROR Failed to load resource",
#     "2025-04-07 DEBUG Memory usage stable",
#     "2025-04-07 ERROR Timeout occurred",
# ]
# # Filter for error lines
# for error in filter_log_lines(log_lines, keyword="ERROR"):
#     print(">>", error)
# Output:
# >> 2025-04-07 ERROR Failed to load resource
# >> 2025-04-07 ERROR Timeout occurred


def live_log(log_lines,keyword):
    for name in log_lines:
        if keyword in name:
            yield name
log_lines = [
    "2025-04-07 INFO User logged in",
    "2025-04-07 ERROR Failed to load resource",
    "2025-04-07 DEBUG Memory usage stable",
    "2025-04-07 ERROR Timeout occurred",
]
for error in live_log(log_lines,keyword="ERROR"):
    print(error)