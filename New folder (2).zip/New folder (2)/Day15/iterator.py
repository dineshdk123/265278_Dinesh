class range:
    def __init__(self,start,end):
        self.start=start
        self.end=end

    def __init__(self):
        self.current = self.start
        return self

    def __next__(self):
        if self.current < self.end:
            result = self.current
            self.current += 1  # Move to the next value
            return result
        else:
            raise StopIteration  # Signal that the iteration is complete

# Create an instance of MyRange
my_range =range(1,5)

# Using the object in a for loop
for num in my_range:
    print(num)
