import unittest
import sys
import os
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))
 
from employee import Employee

class TestEmployee(unittest.TestCase):
    def test_create_employee(self):
        emp = Employee("Dinesh", "IT", "A", "300000", "5000", "3000", "300000")
        self.assertEqual(emp.name, "Dinesh")
        self.assertEqual(emp.department, "IT")
        self.assertEqual(emp.designation, "A")
        self.assertEqual(emp.gross_salary, "300000")
        self.assertEqual(emp.tax, "5000")
        self.assertEqual(emp.bonus, "3000")
        self.assertEqual(emp.net_salary, "300000")
    
    def test_to_dict(self):
        emp = Employee("Ganesh", "Bfarm", "S", "500000", "10000", "3000", "50000")
        data = emp.to_dict()
        self.assertEqual(data["name"], "Ganesh")

    def test_from_dict(self):
        data = {
            "id": "123",
            "name": "kumar",
            "department": "Admin",
            "designation": "Officer",
            "gross_salary": "700000",
            "tax": "7000",
            "bonus": "3000",
            "net_salary": "696000"
        }
        emp = Employee.from_dict(data)
        self.assertEqual(emp.id, "123")
        self.assertEqual(emp.name, "kumar")

if __name__ == "__main__":
    unittest.main()

