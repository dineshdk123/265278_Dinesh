# Use this for manual testing

from bankcli.bankapp.main import app

if __name__ == "__main__":
    app()