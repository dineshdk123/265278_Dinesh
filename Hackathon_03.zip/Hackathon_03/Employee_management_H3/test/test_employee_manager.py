import unittest
import sys
import os
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))
 
from employee_manager import EmployeeManager

class TestEmployeeManager(unittest.TestCase):
    def setUp(self):
        self.manager = EmployeeManager()

    def test_add_and_get_all(self):
        emp = self.manager.add_employee("priya", "medicine", "doctor", "500000", "10000", "3000", "49300")
        all_emps = self.manager.get_all_employee()
        self.assertEqual(len(all_emps), 1)
        self.assertEqual(all_emps[0].name, "priya")

    def test_find_by_id(self):
        emp = self.manager.add_employee("hari", "Finance", "Analyst", "55000", "5000", "2000", "52000")
        found = self.manager.find_by_id(emp.id)
        self.assertIsNotNone(found)
        self.assertEqual(found.name, "hari")

    def test_delete_employee(self):
        emp = self.manager.add_employee("Jerry", "Support", "Agent", "40000", "3000", "1000", "38000")
        result = self.manager.delete_employee(emp.id)
        self.assertTrue(result)
        self.assertEqual(len(self.manager.get_all_employee()), 0)

 
if __name__ == "__main__":
    unittest.main()
