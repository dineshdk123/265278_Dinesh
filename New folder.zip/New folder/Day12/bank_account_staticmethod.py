class bankaccount(object):
    def __init__(self,accholder,balance=0):
        self.accholder=accholder
        self.balance=balance
    
    def deposit(self,amount):
        self.balance +=amount
        print(f"deposited INR is{amount} \n current balance INR{self.balance}")
    
    def withdraw(self,amount):
        if amount> self.balance:
            print("tnsufficinet balanve ")
        else:
            self.balance -=amount
            print(f"deposited INR is{amount} \n current balance INR{self.balance}")
    def set_interset_rate(cls,new_rate):
        cls.interest_rate=new_rate
        print(f"updated interest rate to{cls.interest_rate}")
    
    set_interset_rate=classmethod(set_interest_rate)

    def validate_account_number(account_number):
        return len(str(account_number)) ==12 and str(account_number).isdigit()
    
    validate_account_number=staticmethod(validate_account_number)

if __name__=="__main__":

    acc1=bankaccount("Anil",1999)
    if (bankaccount.validate_account_number("123456789")):
        acc1.deposit(500)
        acc1.withdraw(200)

        bankaccount.set_interset_rate(6)

