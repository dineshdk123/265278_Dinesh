# Step 1
# Read the content

path = r"C:\Users\265278\Documents\Python Training\Day12\students.csv"
f = open(path)
content = f.readlines()
f.close()

print("INFO -> step 1", content)

# Step 2
# Process the content and store in a data structure
# What data structure will be good here? Sanjeev -> Dictionary
# student_dict -> class_dict

class_dict = {}
columns = [item.strip() for item in content[0].split(',')] # Keys of the student dictionary
for dataitem in content[1:]:
    values = [item.strip() for item in dataitem.split(',')] # Values for the student dictionary
    student_dict = dict(zip(columns, values)) # Zipping keys and values to form the student dictionary
    class_dict[student_dict['regid']] = student_dict # Adding student dictionery to class dictionary
    #value=[int(student_dict["phy"]),int(student_dict["chem"]),int(student_dict["math"]),int(student_dict["bio"])]
print("\n" + "-"*100)
print("INFO -> step 2 \n", class_dict)


# Step 3
# Calculate the average 

value=[int(student_dict["phy"]),int(student_dict["chem"]),int(student_dict["math"]),int(student_dict["bio"])]
student_dict['avg']=sum(value)/len(value)
class_dict[student_dict['regid']]=student_dict

sorted_students = sorted(class_dict.values(), key=lambda x: float(x['avg']), reverse=True)
 
# Assign ranks to students

 
print("\n" + "-"*100)
print("INFO -> step 3 -> Class dictionary after averages updated\n", class_dict)

# Step 4
# Calculate the rank
for rank, student in enumerate(sorted_students, start=1):
    student['rank'] = rank
    class_dict[student['regid']] = student

print("\n" + "-"*100)
print("INFO -> step 4 -> Class dictionary after ranks updated\n", class_dict)

# Step 5
# Display the report
template = "{0:8} | {1:15} | {2:5} | {3:5} | {4:5} | {5:5} | {6:5} | {7:5} | {8:5}"
line = '-'*90

print("\nCLASS REPORT")
print(line)
print(template.format('REGID', 'NAME', 'AGE', 'PHY', 'CHEM', 'MATH', 'BIO', 'AVG', 'RANK'))
print(line)
for regid in class_dict.keys():
    name = class_dict[regid]['name']
    id = class_dict[regid]['regid']
    age = class_dict[regid]['age']
    phy = class_dict[regid]['phy']
    chem = class_dict[regid]['chem']
    math = class_dict[regid]['math']
    bio = class_dict[regid]['bio']
    avg = class_dict[regid]['avg']
    rank = class_dict[regid]['rank']
    print(template.format(id, name, age, phy, chem, math, bio, avg, rank))
  
print(line)

file= open("student_report_value.txt",'w')
file.write("Class Result\n")
file.write(line + "\n")
file.write(template.format('REGID', 'NAME', 'AGE', 'PHY', 'CHEM', 'MATH', 'BIO', 'AVG', 'RANK') + "\n")
file.write(line + "\n")
for student in sorted_students:
    name = student['name']
    id = student['regid']
    age = student['age']
    phy = student['phy']
    chem = student['chem']
    math = student['math']
    bio = student['bio']
    avg = student['avg']
    rank = student['rank']
    file.write(template.format(id, name, age, phy, chem, math, bio, avg, rank)+"\n")
file.write(line + "\n")

# file= open("student_report_value1.csv","w")
# file.write("Class Result\n")
# file.write(line + "\n")
# file.write(template.format('REGID', 'NAME', 'AGE', 'PHY', 'CHEM', 'MATH', 'BIO', 'AVG', 'RANK') + "\n")
# file.write(line + "\n")
# for student in sorted_students:
#     name = student['name']
#     id = student['regid']
#     age = student['age']
#     phy = student['phy']
#     chem = student['chem']
#     math = student['math']
#     bio = student['bio']
#     avg = student['avg']
#     rank = student['rank']
#     file.write(template.format(id, name, age, phy, chem, math, bio, avg, rank)+"\n")
# file.write(line + "\n")