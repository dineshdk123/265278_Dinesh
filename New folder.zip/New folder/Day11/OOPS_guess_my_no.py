import random

class Guess_no():
    def __init__(self,max_attempts=10):
        self.max_attempts =max_attempts
        self.attempts = 0
    
    def guessing_no(self):
        self.number_to_guess = random.randint(1, 100)
        print("Guess a number between 1 and 100: ")
 
        while self.attempts < self.max_attempts:
            self.guess = int(input())
 
            self.attempts += 1
 
            if self.guess == self.number_to_guess:
                print(f"Congratulations! You guessed the number in {self.attempts} tries.")
                break
            elif self.guess < self.number_to_guess:
                print(f"Your guess is too low. You have {self.max_attempts - self.attempts} tries left.")
            else:
                print(f"Your guess is too high. You have {self.max_attempts - self.attempts} tries left.")
   
        if self.guess != self.number_to_guess:
            print(f"Sorry! You didn't guess the number. The number was {self.number_to_guess}.")
 
# Run the guessing game
g1=Guess_no(20)
g1.guessing_no()

