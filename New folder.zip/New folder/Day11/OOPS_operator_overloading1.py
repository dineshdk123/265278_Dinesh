class time(object):
    def __init__(self,hours,minutes,seconds):
        self.hours=hours
        self.miniutes=minutes
        self.seconds=seconds

    def __add__(self,other)