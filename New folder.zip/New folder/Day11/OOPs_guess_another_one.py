import random
 
class GuessTheGame(object):
    def __init__(self, max_attempts=10):
 
        # Generate a random number between 01 and 100 for the player to guess
        self.target_number = random.randint(1, 100)
       
        # Print introductory message
        print("\t\t\t\t\t\t GUESS THE NUMBER\n\t\t\t\t\tdeveloped by ABHIJIT MANDAL")
 
        # Random numbers for generating range hints
       
        self.lower_hint_range = random.randint(1, 50)  # Random value for generating lower bound of the range
        self.upper_hint_range = random.randint(1, 60)  # Random value for generating upper bound of the range
        self.upper_offset = random.randint(1, 4)        # Random value to help generate upper offset for a hint
        self.lower_offset = random.randint(1, 4)        # Random value to help generate lower offset for a hint
       
        # Calculate the hint ranges based on the target number
        self.lower_bound = self.target_number - self.lower_hint_range  # Lower bound of the hint range
        self.upper_bound = self.target_number + self.upper_hint_range  # Upper bound of the hint range
        self.just_crossed = self.target_number + self.upper_offset    # A little higher than the actual number to give a "just crossed" hint
        self.just_behind = self.target_number - self.lower_offset    # A little lower than the actual number to give a "just behind" hint
       
        # Print how many chances the player has
        print("You have only 10 chances to guess the number!")
 
    def play_game(self):
        # Initialize the number of guesses made by the player
        attempts_left = 10
       
        # Loop that continues as long as the player has not reached 10 attempts
        while attempts_left > 0:
            # HINT
            print(f"Range is from {self.lower_bound} to {self.upper_bound}")
           
   
            player_guess = int(input("Guess the number: "))
           
           
            if player_guess == self.target_number:
                print(f"Congratulations! You guessed the right number in {11 - attempts_left} chance(s).")
                break  
           
            # Check if the guess is too low
            elif player_guess < self.target_number:
               
                if player_guess >= self.just_behind:
                    print("Oh! You're just behind! Try again.")
                else:
                    print("No, it's too low!")
           
            # Check if the guess is too high
            elif player_guess > self.target_number:
           
                if player_guess <= self.just_crossed:
                    print("Oh! You just crossed the number!")
                else:
                    print("No, it's too high!")
           
            # Print the remaining number of attempts
            print(f"You only have {attempts_left - 1} chances left.")
            attempts_left -= 1  
           
            # If reached to 10
            if attempts_left == 0:
                print("\n\nGame Over!!!")
                print(f"The correct number was: {self.target_number}")
 
# create class
game = GuessTheGame()
 
# Start the guessing game
game.play_game()