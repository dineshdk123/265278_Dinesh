class employee():
    def __init__(Self,name,age,company,gross_salary,tax_rate):
        Self.name=name
        Self.age=age
        Self.company=company
        Self.gross_salary=gross_salary
        Self.tax_rate=tax_rate

    def net_salary(Self):
        return (self.gross_salary*self.tax_rate)/100
