# def noramlizespace(n):
#     print("".join(n.split()))
    
# value=input("enter a line:")
# noramlizespace(value)

# def reverse(n):
#     print (n[::-1])
# value=input("Enter a reverse word")
# reverse(value)

# import string
# def punctuation(n):
#     for i in n:
#         if i not in string.punctuation:
#             print(i,end="")
# value=input("Enter a punctuation sentence ")
# punctuation(value)

# def count_words(n):
#     value=n.split()
#     value1=len(value)
#     print(value1)
# words=input("Enter a words:")
# count_words(words)

import itertools

