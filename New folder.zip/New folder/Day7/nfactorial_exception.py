
# value=1
# for i in range(1,n+1):
#     value=i*value
#     print(value)
try :
    def factorial(n):
        if n <= 0:
            raise ValueError("Input must be greater than 0")  
        result = 1
        for i in range(1, n + 1):
            result *= i
        return result
    value=int(input("enter a no:"))
    print(factorial(value))
except ValueError as e:
    print(f"the error is {e}")
else:
    print("the factorial completed")
