import random

# Function to read words and clues from a file and return them as a list of dictionaries
def read_words_and_clues(filename):
    words_and_clues = []
    path=r"C:\Users\265278\Documents\Python Training\Day7\word1.txt"
    f = open(path,"r")
    content = f.read()
    f.close()
    lines = file.read().strip().split('---')
    for line in lines:
        word_clue = line.strip().split('\n')
        word = word_clue[0].strip()
        clue = word_clue[1].strip()
        words_and_clues.append({'word': word, 'clue': clue})
    return words_and_clues

# Function to calculate the grade based on total points
def calculate_grade(total_points):
    if total_points >= 16:
        return "A"
    elif total_points >= 12:
        return "B+"
    elif total_points >= 8:
        return "B"
    elif total_points >= 4:
        return "C+"
    else:
        return "C"

# Function to play the guessing game
def guessing_game():
    # Read the words and clues from the file
    words_and_clues = read_words_and_clues('words_and_clues.txt')

    # Initialize counters for correct guesses, first and second attempts
    correct_first_attempts = 0
    correct_second_attempts = 0
    total_points = 0
    total_first_attempts = 0
    total_second_attempts = 0

    # Randomly select a word and clue
    selected_word_data = random.choice(words_and_clues)
    word_to_guess = selected_word_data['word']
    clue = selected_word_data['clue']

    print("Can you guess the word?")

    # First attempt
    first_guess = input("Your first guess: ").strip().lower()

    # Check if the first guess is correct
    if first_guess == word_to_guess:
        total_points += 2  # 2 points for a correct first attempt
        total_first_attempts += 1
        correct_first_attempts += 1
        print("✅ Correct!")
    else:
        # Provide a clue after the first failed attempt
        print("❌ Incorrect guess.")
        print(f"CLUE: {clue}")

        # Second attempt
        second_guess = input("Take a second guess: ").strip().lower()

        # Check if the second guess is correct
        if second_guess == word_to_guess:
            total_points += 1  # 1 point for a correct second attempt
            total_second_attempts += 1
            correct_second_attempts += 1
            print("✅ Correct!")
        else:
            print("❌ Incorrect guess.")
            print(f"Sorry, the correct word was: {word_to_guess}")
    
    # Calculate the grade
    grade = calculate_grade(total_points)

    # Display results
    print(f"\nTotal Points: {total_points}")
    print(f"First Attempts: {total_first_attempts}")
    print(f"Second Attempts: {total_second_attempts}")
    print(f"Correct First Attempts: {correct_first_attempts}")
    print(f"Correct Second Attempts: {correct_second_attempts}")
    print(f"Overall Grade: {grade}")

# Run the game
guessing_game()
