try:   
    li = []
    def spansub(stri, substri):
        if substrio=="" or stri=="":
            raise Exception("Please provide the proper substrio")
        x = len(substri)
        for i in range(len(stri)):
            subs = x+i
            if substri == stri[i:subs]:
                li.append((i,subs))
 
            print(len(li), li)
 
    if __name__ == "__main__":
        strio = input("enter the string")
        substrio = input("enter the sub_string")
        spansub(strio, substrio) 
except Exception as e:
    print(f"the value is error{e}")
else:
    print("completed string")