# 3️⃣ Class with Methods and Properties: Rectangle
# ------------------------------------------------------------------
# Task: Design a Rectangle class:
# Attributes: length, width
# Methods:
# area(): Returns area.
# perimeter(): Returns perimeter.
# is_square(): Returns True if it’s a square, otherwise False.
# ✅ Enhance: Use logic to prevent setting negative values for length and width.

class shapes():
    def __init__(Self,length,width):
        Self.length=length
        Self.width=width

    def check_inputs(self):
        if(self.length<0):
            self.length=abs(self.length)
        if(self.width<0):
            self.width=abs(self.width)  

    def area(Self):
        print(f"the area of the value :{Self.length*Self.width}")
    
    def perimeter(Self):
        Self.perimeter=(2*(Self.length+Self.width))
        print(f"the perimeter of the value :{Self.length+Self.width}")
                
    def is_square(Self):
        if Self.length==Self.width:
            print("current lenght and width is consider as square")
        else:
            print("this is not square")
shapes1=shapes(4,4)
shapes1.area()
shapes1.perimeter()
shapes1.is_square()

class Cuboid(shapes):
        def __init__(self,length,width,height):
            self.height=height
            super().__init__(length,width)
        def volume(self):
            return (super().area())*(self.height)
        def surface_area(self): 
            # print((self.area())+(self.height*self.length)+(self.height*self.length))
            return 2*(super().area())+(self.height*self.length)+(self.height*self.length)
 
 
a=int(input("enter the length"))
b=int(input("enter the breadth"))
c=int(input("enter the height"))
 
if(a>0 and b>0 and c>0):
    R=Cuboid(a,b,c)
    print("volume",R.volume())
    print("surface",R.surface_area())
else:
    print("length and breadth and height should positve")
