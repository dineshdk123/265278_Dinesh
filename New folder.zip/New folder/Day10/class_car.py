# 1️⃣ Basic Class Creation: Car
# ------------------------------------------------------------------
# Task: Create a class Car with attributes and methods as follows:
# Attributes: brand, model, year, mileage
# Methods:
# drive(distance): Increases mileage by distance.
# display_info(): Prints all details of the car.
# ✅ Enhance: Add a fuel_level attribute and a method refuel(amount) to increase it.
# Adjust rest of the attributes accordinly

class car():
    def __init__(self,brand,model,year,mileage,fuel_level):
        self.brand=brand
        self.model=model
        self.year=year
        self.mileage=mileage
        self.fuel_level=fuel_level

    def drive(self, distance):
        if self.fuel_level > 0:
            self.mileage += distance
            self.fuel_level -= distance * 0.2  # Assume fuel consumption is 0.2 liters per km
            if self.fuel_level < 0:
                self.fuel_level = 0
            print(f"Drove {distance} km. Remaining fuel level: {self.fuel_level:.2f} liters.")
        else:
            print("Cannot drive. Please refuel the car!")
    
    def display_info(self):
        print(f"Car Details: \nBrand: {self.brand}\nModel: {self.model}\nYear: {self.year}\nMileage: {self.mileage} miles\nFuel Level: {self.fuel_level}")

    def refuel(self, amount):
        self.fuel_level += amount
        print(f"Refueled {amount} units. Fuel level now: {self.fuel_level:.2f}.")

my_car=car("Benz","benz_omtrix",2025,5,15)
my_car.display_info()
my_car.drive(20)
my_car.refuel(10)
my_car.display_info()   

# Tasks:
# Implement a class Car with attributes:
# brand, model, year, mileage
# Add methods:
# drive(distance): Increases mileage
# display_info(): Displays car details
# Create a subclass ElectricCar with additional attributes:
# battery_capacity, charge_level (default 100)
# Add a method:
# charge(amount): Increases charge level (max 100).
# Override display_info() to include battery details.
# Create objects for both classes and demonstrate method usage.

class ElectricCar(car):
    def __init__(Self,brand,model,year,mileage,fuel_level,battery_level):
        Self.battery_level=battery_level
        Self.amount=0
        super().__init__(brand,model,year,mileage,fuel_level)

    def charge(Self,amount):
        if Self.amount>=0 and Self.amount<=100:
            print(f"charge level of battery is {Self.amount}")
        else:
            print("the battery percentage is greater than 0")
        
    def print(Self):
        #super().print(f"Car Details: \nBrand: {self.brand}\nModel: {self.model}\nYear: {self.year}\nMileage: {self.mileage} miles\nFuel Level: {self.fuel_level}")
        print(Self.charge)
carss=ElectricCar("Benz","benz_omtrix",2025,5,15,100)
carss.charge(50)