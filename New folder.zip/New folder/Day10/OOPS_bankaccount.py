# Task: Implement a BankAccount class with:
# Attributes: balance, account_number
# Methods:
# deposit(amount): Adds money to balance.
# withdraw(amount): Deducts money if enough balance is available.
# get_balance(): Returns balance.
# ✅ Enhance: Prevent withdrawal if balance falls below a minimum threshold.

class bank_account():
    def __init__(Self, balance,account_no,minimum_balance=500):
        Self.balance=balance
        Self.account_no=account_no
        Self.minimum_balance=minimum_balance
    
    def deposit(Self,amount):
        if amount >0:
            Self.balance += amount
            print(f"amount is {amount}, now current balance is {Self.balance:.2f}")
        else:
            print("amount must be postive value")

    def withdraw(Self,amount):
        if amount>0:
            if Self.balance - amount >= Self.minimum_balance:
                Self.balance -= amount
                print(f"Withdrew {amount}. Current balance: {Self.balance:.2f}")
            else:
                print(f"Cannot withdraw {amount}. Balance cannot fall below the minimum threshold of {Self.minimum_balance}.") 

    def get_balance(self):
        return self.balance

    def display_info(Self):
        print("the account no is ".ljust(20), Self.account_no)
        print("the balance is".ljust(20),Self.get_balance())

my_account = bank_account(500,"12345")  
my_account.deposit(200) 
my_account.withdraw(300)  
my_account.withdraw(500)  
print(f"Current balance: {my_account.get_balance()}")   

class saving_account(bank_account):
    def __init__(Self,balance,account_no,interest_rate,minimum_balance=500):
        Self.interest_rate=interest_rate
        #Self.add_interest=add_interest
        super().__init__(balance,account_no,minimum_balance=500)

    def add_interest(Self):
        interest=(Self.balance * Self.interest_rate)
        Self.balance+=interest
        print(Self.add_interest)
    
    def display_info(Self):
        super().display_info()
        print(Self.interest_rate)

saving1=saving_account(500,"12345",0.025)
saving1.add_interest()
saving1.display_info()

    

    
        



