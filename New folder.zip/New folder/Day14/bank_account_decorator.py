# Create a class called BankAccount to represent a user’s bank account. 
# The class should allow the following:

# Use @property to return the current balance with a message like "Your balance is ₹5000".

# Use @classmethod to create a BankAccount from a dictionary containing account details like:
# {"name": "Alice", "balance": 10000}

# Use @staticmethod to check if a given withdrawal amount is valid, i.e., 
# it must be a positive number and less than or equal to the current balance.

class bank_account(object):
    def __init__(self,name,balance):
        self.name=name
        self.balance=balance
    
    @property
    def current_balance(self):
        return f"your current balance is {self.balance}"
    
    @classmethod
    def account_details(cls,account):
        return cls(account["name"] ,account["balance"])
        
    @staticmethod
    def valid_withdraw(amount,balance):
        if  0<amount<=balance:
            print ("your have valid amount to withdraw")
        else:
            print("Plz check the bank account")

bank = bank_account("Dinesh", 4000)
print(bank.current_balance)  # Output: Your balance is ₹4000

# Create BankAccount instance from a dictionary
account_info = {"name": "Alice", "balance": 10000}
new_bank =bank_account.account_details(account_info)
print(new_bank.current_balance)  # Output: Your balance is ₹10000

# Using the static method to validate a withdrawal
bank_account.valid_withdraw(1000, bank.balance)  # Valid withdrawal
bank_account.valid_withdraw(5000, bank.balance)