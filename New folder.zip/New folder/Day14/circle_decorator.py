'''
Create a Python class called Circle that represents a circle. The class should allow the following:
 
Use @property to return the circumference of the circle using the formula 2 * π * radius.
 
Use @classmethod to create a Circle instance from a diameter.
 
Use @staticmethod to check if a given value is a valid radius (i.e., a positive number).
'''
class circle(object):
    def __init__(self,radius):
        self.radius=radius

    @property
    def circumference_circle(self):
        return 2 * 3.14 * self.radius
    
    @classmethod
    def circle_diameter(cls,diameter):
        return cls(diameter/2)
       
    @staticmethod
    def valid_radius(n):
        if n >0:
            print("postive no")
        else:
            print("INvalid no")

circle1=circle(8)
print(circle1.circumference_circle)
print(circle1.circle_diameter(6))
print(circle1.valid_radius)



        
