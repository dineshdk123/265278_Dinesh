from django.contrib import admin
from .models import Consumable

# Register your models here.

admin.site.register(Consumable)
