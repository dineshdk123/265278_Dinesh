from django import forms

class LoanApplicationForm(forms.Form):
    Age = forms.IntegerField(label="Age")
    Monthly_Income = forms.FloatField(label="Monthly Income (₹)")
    Credit_Score = forms.IntegerField(label="Credit Score (300-850)")
    Loan_Tenure_in_Years = forms.FloatField(label="Loan Tenure (Years)")
    Existing_Loan_Amount = forms.FloatField(label="Existing Loan Amount (₹)")
    Number_of_Dependents = forms.IntegerField(label="Number of Dependents")